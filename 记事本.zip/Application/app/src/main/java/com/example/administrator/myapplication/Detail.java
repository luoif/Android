package com.example.administrator.myapplication;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.view.Menu;
import android.view.MenuItem;

import android.widget.EditText;
import android.widget.Toast;

import static com.example.administrator.myapplication.DatabaseHelper.TABLE_NAME;
import static com.example.administrator.myapplication.MainActivity.TAG_INSERT;
import static com.example.administrator.myapplication.MainActivity.TAG_UPDATE;
import static com.example.administrator.myapplication.MainActivity.dbHelper;
import static com.example.administrator.myapplication.MainActivity.getDbHelper;


public class Detail extends AppCompatActivity {


    private SQLiteDatabase db;
    EditText 主题;
    EditText 请输入;
    public DatabaseHelper deHelper=getDbHelper();
    private int tag;
    private int id;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        主题=(EditText)findViewById(R.id.detail_title);
        请输入=(EditText)findViewById(R.id.detail_content);
        主题.setSelection(主题.getText().length());
        请输入.setSelection(请输入.getText().length());
        db= dbHelper.getWritableDatabase();
        Intent intent=getIntent();
        tag=intent.getIntExtra("TAG",-1);
        switch(tag){
            case TAG_INSERT:
                break;
            case TAG_UPDATE:
                id=intent.getIntExtra("ID",-1);
                Cursor cursor=db.query(TABLE_NAME,null,"id=?",
                        new String[]{String.valueOf(id)},null,null,null);
                if(cursor.moveToFirst()){
                    String select_title=cursor.getString(cursor.getColumnIndex("title"));
                    String select_content=cursor.getString(cursor.getColumnIndex("content"));
                    主题.setText(select_title);
                    请输入.setText(select_content);
                    //  Log.d("Ditail","title:"+select_title);
                    //  Log.d("Detail","content"+select_content);
                }
                break;
            default:
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()){
            case R.id.保存成功:
                if(tag==TAG_INSERT) {
                    ContentValues values = new ContentValues();
                    values.put("title", 主题.getText().toString());
                    values.put("content", 请输入.getText().toString());
                    db.insert(TABLE_NAME, null, values);
                    values.clear();
                    Toast.makeText(this, "添加成功", Toast.LENGTH_SHORT).show();
                    finish();
                    break;
                }else if(tag==TAG_UPDATE){

                    String update_title=主题.getText().toString();
                    String update_content=请输入.getText().toString();
                    ContentValues values=new ContentValues();
                    values.put("title",update_title);
                    values.put("content",update_content);
                    db.update(TABLE_NAME,values,"id=?",new String[]{String.valueOf(id)});
                    finish();
                    break;
                }
            case R.id.删除成功:
                if(tag==TAG_UPDATE) {
                    db.delete(TABLE_NAME,"id=?",new String[]{String.valueOf(id)});
                }
                Toast.makeText(this,"删除成功",Toast.LENGTH_SHORT).show();
                finish();
                break;
            default:
        }
        return true;
    }
}

